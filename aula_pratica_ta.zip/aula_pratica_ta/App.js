import { Image, Text, SafeAreaView, StyleSheet } from 'react-native';
export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Image style={styles.logo} source={require('./assets/senailogo.png')} />
      <Text style={styles.texto1}>Meu Primeiro Aplicativo</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'purple',
    padding: 8,
  },
  texto1: {
    color: 'yellow',
    margin: 24,
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    margin: 24,
    backgroundColor: 'brown',
  },
  logo: {
    height: 190,
    width: 190,
    resizeMode: 'stretch',
    borderRadius: 75,
  },
});
