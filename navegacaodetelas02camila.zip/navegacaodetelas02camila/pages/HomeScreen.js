// React Native Bottom Navigation
// https://aboutreact.com/react-native-bottom-navigation/

import { useState } from 'react';

import {
  TouchableOpacity,
  StyleSheet,
  View,
  Text,
  SafeAreaView,
  Image,
  ScrollView,
  TextInput,
} from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'black' }}>
      <View style={{ flex: 1 }}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <View>
            <Image
              style={styles.logo}
              source={require('../assets/navegacao.jpg')}
            />
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Pagina1')}>
            <Text> Angular</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Pagina2')}>
            <Text> Flutter</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Pagina3')}>
            <Text> Ionic</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Pagina4')}>
            <Text> React Expo</Text>
          </TouchableOpacity>

            <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Pagina5')}>
            <Text> React Native</Text>
          </TouchableOpacity>

           <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Pagina6')}>
            <Text> Xamarin</Text>
            </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    backgroundColor: '#87CEFA',
    padding: 10,
    width: 150,
    marginTop: 12,
    fontFamily: 'century gothic',
    borderRadius: 10,
  },

  logo: {
    width: 200,
    resizeMode: 'contain',
    height: 120,
  },
});
export default HomeScreen;
