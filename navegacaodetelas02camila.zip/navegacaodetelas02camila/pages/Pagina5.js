
import React, { Component, useState, useEffect } from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function Pagina5({navigation}) {
  return (
    <View
      style={{
        flex:1,
        backgroundColor: 'black',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#000000',
          padding: 10,
        }}>
        <Image
          style={styles.logo}
          source={require('../assets/navegacao.jpg')}
        />
        <Image style={styles.ima} source={require('../assets/reactnative.jpg')} />
        <View
          style={{
            backgroundColor: 'green', padding:10, borderRadius:10
          }}>
          <Text style={{ color: '#fff', textAlign: 'center', }}>
           React Native: Framework nativo com React. Bom desempenho, base de código única, mas pode exigir módulos nativos.
          </Text>
        </View>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Home')}>
          <Text> Voltar </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  logo: {
    width: 200,
    resizeMode: 'contain',
    height: 120,
  },
  ima: {
    width: 300,
    resizeMode: 'contain',
    height: 220,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#87CEFA',
    padding: 10,
    width: 150,
    marginTop: 12,
    fontFamily: 'century gothic',
    borderRadius: 10,
  },
});
