import React, { Component, useState, useEffect } from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function Pagina2({navigation, route}) {
  return (
    <View
      style={{
        flex:1,
        backgroundColor: 'black',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#000000',
          padding: 10,
        }}>
        <Image
          style={styles.logo}
          source={require('../assets/navegacao.jpg')}
        />
        <Image style={styles.ima} source={require('../assets/flutter.jpg')} />
        <View
          style={{
              backgroundColor: 'green', padding:10, borderRadius:10
          }}>
          <Text style={{ color: '#fff', textAlign: 'center', padding:10 }}>
           Ionic: Framework híbrido baseado em tecnologias web (HTML, CSS, JS). Fácil de usar, mas desempenho inferior ao nativo. 
          </Text>
        </View>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Home')}>
          <Text> Voltar </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  logo: {
    width: 200,
    resizeMode: 'contain',
    height: 120,
  },
  ima: {
    width: 300,
    resizeMode: 'contain',
    height: 220,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#87CEFA',
    padding: 10,
    width: 150,
    marginTop: 12,
    fontFamily: 'century gothic',
    borderRadius: 10,
  },
});
