import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image } from 'react-native';

export default function LoginScreen() {
  // Definição dos states para os novos campos
  const [nomeCompleto, setNomeCompleto] = useState('');
  const [nomePai, setNomePai] = useState('');
  const [nomeMae, setNomeMae] = useState('');
  const [cpf, setCpf] = useState('');
  const [rg, setRg] = useState('');

  // Função que mostra as informações armazenadas nos states
  const mostrarInformacoes = () => {
    alert(`Informações do usuário: \nNome Completo: ${nomeCompleto}\nNome do Pai: ${nomePai}\nNome da Mãe: ${nomeMae}\nCPF: ${cpf}\nRG: ${rg}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}> Sistema de Cadastro </Text>
      <Image
        source={require('./components/rosto.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <TextInput
        style={styles.input}
        placeholder="Nome Completo"
        placeholderTextColor="gray"
        value={nomeCompleto}
        onChangeText={setNomeCompleto}
      />
      <TextInput
        style={styles.input}
        placeholder="Nome do Pai"
        placeholderTextColor="gray"
        value={nomePai}
        onChangeText={setNomePai}
      />
      <TextInput
        style={styles.input}
        placeholder="Nome da Mãe"
        placeholderTextColor="gray"
        value={nomeMae}
        onChangeText={setNomeMae}
      />
      <TextInput
        style={styles.input}
        placeholder="CPF"
        placeholderTextColor="gray"
        value={cpf}
        onChangeText={setCpf}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="RG"
        placeholderTextColor="gray"
        value={rg}
        onChangeText={setRg}
      />
      <View style={styles.bottomContainer}>
        <TouchableOpacity style={styles.loginButton} onPress={mostrarInformacoes}>
          <Text style={styles.loginButtonText}>Cadastrar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor:"blue",   
  },
  titulo: {
    color: "white",
    fontSize: 40,
    fontWeight: "bold",
    paddingTop: 100,
    margin: 30,
  },
  logo: {
    width: 200,
    height: 200,
    marginBottom: 20,
    borderRadius: 100,
  },
  input: {
    height: 40,
    color: "#A52A2A",
    width: '80%',
    backgroundColor: "white",
    borderColor: 'white',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingLeft: 10,
  },
  bottomContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 20,
    width: '80%',
  },
  loginButton: {
    backgroundColor: 'yellow',
    padding: 10,
    borderRadius: 5,
    width: '100%',
    alignItems: 'center',
  },
  loginButtonText: {
    color: 'black',
    fontSize: 20,
    fontWeight: "bold",
  },
});

