import React, { useState } from 'react';
import { Snackbar } from 'react-native-paper';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Image,
} from 'react-native';

export default function CalculatorApp() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState('');

  // cria state para controlar a visibilidade da snackbar, inicia false
  const [visible, setVisible] = useState(false);

  // mostra snackbar com mensagem, visibilidade é verdadeira
  const showSnackbar = (resp) => {
    setResult(resp);
    setVisible(true);
  };

  // desabilita snackbar tornando o state false
  const hideSnackbar = () => {
    setVisible(false);
  };

  // a função abaixo recebe o operador e realiza a operação
  // armazenando a resposta no state result
  const executarOperacao = (operador) => {
    if (!num1 || !num2) {
      showSnackbar('Insira ambos os números.');
      return;
    }
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);

    switch (operador) {
      case '+':
        showSnackbar(`Soma: ${number1 + number2}`);

        break;
      case '-':
        showSnackbar(`Subtração: ${number1 - number2}`);

        break;
      case '*':
        showSnackbar(`Multiplicação: ${number1 * number2}`);

        break;
      case '/':
        if (number2 !== 0) {
          showSnackbar(`Divisão: ${number1 / number2}`);
        } else {
          showSnackbar('Divisão por zero não é permitida.');
        }
        break;
      default:
        showSnackbar('Operação inválida.');
    }
  };

  // Novas operações com o primeiro número
  const operarComNum1 = (operador) => {
    if (!num1) {
      showSnackbar('Insira o número.');
      return;
    }
    const number1 = parseFloat(num1);

    switch (operador) {
      case 'squared':
        showSnackbar(`Quadrado: ${number1 * number1}`);

        break;
      case 'cubed':
        showSnackbar(`Cubo: ${number1 * number1 * number1}`);

        break;
      case 'sqrt':
        if (number1 >= 0) {
          showSnackbar(`Raiz Quadrada: ${Math.sqrt(number1)}`);
        } else {
          showSnackbar(
            'Não é possível calcular a raiz quadrada de um número negativo.'
          );
        }
        break;
      case 'parity':
        showSnackbar(number1 % 2 === 0 ? 'Número Par' : 'Número Ímpar');
        break;
      default:
        showSnackbar('Operação inválida.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 30, textAlign: 'center', fontWeight: 'bold' }}>
        Calculadora
      </Text>
      <Image
        style={styles.stretchImage}
        source={require('./components/calculadora.jpg')}
        resizeMode="stretch"
      />
      <TextInput
        style={styles.input}
        placeholder="Número 1"
        keyboardType="numeric"
        value={num1}
        onChangeText={(text) => setNum1(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Número 2"
        keyboardType="numeric"
        value={num2}
        onChangeText={(text) => setNum2(text)}
      />
      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => executarOperacao('+')}>
          <Text style={styles.buttonText}>+</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => executarOperacao('-')}>
          <Text style={styles.buttonText}>-</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => executarOperacao('*')}>
          <Text style={styles.buttonText}>*</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => executarOperacao('/')}>
          <Text style={styles.buttonText}>/</Text>
        </TouchableOpacity>
      </View>

      {/* Novos botões para operações com o primeiro número */}
      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => operarComNum1('squared')}>
          <Text style={styles.buttonText}>²</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => operarComNum1('cubed')}>
          <Text style={styles.buttonText}>³</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => operarComNum1('sqrt')}>
          <Text style={styles.buttonText}>√</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => operarComNum1('parity')}>
          <Text style={styles.buttonText}>Par/Ímpar</Text>
        </TouchableOpacity>
      </View>

      <Snackbar
        style={{ backgroundColor: 'purple', borderRadius: 10, width: '100%' }}
        visible={visible}
        onDismiss={hideSnackbar}
        action={{
          label: 'Fechar',
          onPress: () => {
            // Ação quando o botão "Fechar" for pressionado
          },
        }}>
        <Text>Resposta: {result}</Text>
      </Snackbar>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingLeft: 10,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    backgroundColor: 'purple',
    padding: 10,
    borderRadius: 5,
    width: '23%',
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  stretchImage: {
    width: 280,
    height: 210,
    borderRadius: 170,
    borderColor: '#c0c0c0',
    borderWidth: 1,
    margin: 20,
  },
});
